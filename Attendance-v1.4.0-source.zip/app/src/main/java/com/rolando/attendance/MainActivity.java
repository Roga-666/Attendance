package com.rolando.attendance;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.DayOfWeek;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(16, 28, 44);
    private static final int TEAL = Color.rgb(0, 175, 155);
    private static final int CORAL = Color.rgb(255, 90, 82);
    private static final DateTimeFormatter FULL_DATE = DateTimeFormatter.ofPattern("EEEE, MMMM d, uuuu", Locale.US);
    private static final DateTimeFormatter SHORT_DATE = DateTimeFormatter.ofPattern("EEE, MMM d, uuuu", Locale.US);
    private static final DateTimeFormatter MONTH_LABEL = DateTimeFormatter.ofPattern("MMM uuuu", Locale.US);
    private static final int EXPORT_BACKUP = 401;
    private static final int IMPORT_BACKUP = 402;
    private static final int DRIVE_CREATE = 403;
    private static final int DRIVE_OPEN = 404;

    private enum Mode { TARDY, HOURS, SETTINGS }
    private enum Filter {
        DAYS_30("Last 30 days"), MONTH("This month"), YEAR("This year"), ALL("All time");
        final String label;
        Filter(String label) { this.label = label; }
    }
    private enum HoursFilter {
        CURRENT_WEEK("Current Week"), LAST_WEEK("Last Week"), CURRENT_PAY_PERIOD("Current Pay Period"), LAST_PAY_PERIOD("Last Pay Period");
        final String label;
        HoursFilter(String label) { this.label = label; }
    }
    private enum SettingsCategory { GENERAL, TIME, DATA }

    private AttendanceDb db;
    private SharedPreferences prefs;
    private boolean darkMode;
    private int PAPER, INK, MUTED, CARD_COLOR, BORDER;
    private FrameLayout root;
    private LinearLayout content;
    private LinearLayout drawer;
    private View scrim;
    private boolean drawerOpen;
    private float touchDownX, touchDownY;
    private Mode mode = Mode.TARDY;
    private Filter tardyFilter = Filter.DAYS_30;
    private HoursFilter hoursFilter = HoursFilter.CURRENT_WEEK;
    private YearMonth selectedTardyMonth = YearMonth.now();
    private int selectedTardyYear = LocalDate.now().getYear();
    private LocalDate selectedTardyDate = LocalDate.now();
    private LocalDate selectedHoursDate = LocalDate.now();
    private String activeAttendanceHistoryType;
    private SettingsCategory settingsCategory = SettingsCategory.GENERAL;
    private String settingsNotice;

    @Override protected void onCreate(Bundle state) {
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        darkMode = prefs.getBoolean("dark_mode", false);
        setTheme(darkMode ? R.style.AppThemeDark : R.style.AppTheme);
        super.onCreate(state);
        PAPER = darkMode ? Color.rgb(16, 21, 29) : Color.rgb(245, 247, 250);
        INK = darkMode ? Color.rgb(235, 240, 246) : Color.rgb(35, 45, 58);
        MUTED = darkMode ? Color.rgb(166, 179, 193) : Color.rgb(102, 116, 132);
        CARD_COLOR = darkMode ? Color.rgb(28, 37, 50) : Color.WHITE;
        BORDER = darkMode ? Color.rgb(58, 70, 85) : Color.rgb(213, 221, 230);
        Window window = getWindow();
        window.setStatusBarColor(NAVY);
        window.setNavigationBarColor(NAVY);
        db = new AttendanceDb(this);
        buildShell();
        showDefaultMode();
        if (prefs.getBoolean("drive_sync", false) && prefs.contains("drive_uri")) syncDrive(false);
    }

    private void buildShell() {
        root = new FrameLayout(this);
        root.setBackgroundColor(PAPER);
        root.setFitsSystemWindows(true);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, matchFrame());

        scrim = new View(this);
        scrim.setBackgroundColor(Color.argb(145, 0, 0, 0));
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> closeDrawer());
        root.addView(scrim, matchFrame());

        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setPadding(dp(18), dp(24), dp(18), dp(18));
        drawer.setBackgroundColor(NAVY);
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(dp(286), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START);
        root.addView(drawer, drawerParams);
        buildDrawer();
        drawer.post(() -> drawer.setTranslationX(-drawer.getWidth()));
        setContentView(root);
    }

    private void buildDrawer() {
        LinearLayout brand = horizontal();
        ImageButton logo = new ImageButton(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setPadding(0, 0, 0, 0);
        logo.setBackgroundColor(Color.TRANSPARENT);
        logo.setContentDescription("Open default screen");
        logo.setOnClickListener(v -> { closeDrawer(); showDefaultMode(); });
        brand.addView(logo, new LinearLayout.LayoutParams(dp(72), dp(72)));
        LinearLayout brandCopy = new LinearLayout(this);
        brandCopy.setOrientation(LinearLayout.VERTICAL);
        brandCopy.setPadding(dp(12), 0, 0, 0);
        TextView app = label("Attendance", 23, Color.WHITE, true);
        brandCopy.addView(app, lpMatchWrap(dp(2)));
        TextView tag = label("Keep your own record.", 13, Color.rgb(174, 201, 204), false);
        brandCopy.addView(tag);
        brand.addView(brandCopy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        drawer.addView(brand, lpMatchWrap(dp(26)));
        drawer.addView(navButton("!", "Tardy & Call-Outs", () -> { mode = Mode.TARDY; activeAttendanceHistoryType = null; closeDrawer(); showTardy(); }));
        drawer.addView(navButton("◷", "Hours", () -> { mode = Mode.HOURS; closeDrawer(); showHours(); }));
        Space space = new Space(this);
        drawer.addView(space, new LinearLayout.LayoutParams(1, 0, 1));
        drawer.addView(navButton("⚙", "Settings", () -> { mode = Mode.SETTINGS; closeDrawer(); showSettings(); }));
    }

    private LinearLayout navButton(String iconText, String text, Runnable action) {
        LinearLayout row = horizontal();
        row.setPadding(dp(10), 0, dp(12), 0);
        row.setBackground(roundRect(Color.rgb(27, 46, 66), 14));
        row.setClickable(true);
        row.setFocusable(true);
        row.setContentDescription(text);
        row.setOnClickListener(v -> action.run());

        TextView icon = label(iconText, 17, Color.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(bordered(Color.rgb(38, 63, 85), TEAL, 100));
        row.addView(icon, new LinearLayout.LayoutParams(dp(36), dp(36)));
        TextView title = label(text, 14, Color.WHITE, true);
        title.setPadding(dp(14), 0, 0, 0);
        row.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.setLayoutParams(lpMatch(dp(56), dp(8)));
        return row;
    }

    private void showDefaultMode() {
        if ("HOURS".equals(prefs.getString("default_mode", "TARDY"))) {
            mode = Mode.HOURS;
            showHours();
        } else {
            mode = Mode.TARDY;
            showTardy();
        }
    }

    private void toolbar(String title) {
        toolbar(title, false);
    }

    private void toolbar(String title, boolean showBack) {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(6), dp(16), dp(6));
        bar.setBackgroundColor(NAVY);
        Button navigation = button(showBack ? "‹" : "☰", NAVY, Color.WHITE);
        navigation.setTextSize(showBack ? 36 : 25);
        navigation.setContentDescription(showBack ? "Back to summary" : "Open navigation");
        navigation.setOnClickListener(v -> {
            if (showBack) {
                activeAttendanceHistoryType = null;
                showTardy();
            } else openDrawer();
        });
        bar.addView(navigation, new LinearLayout.LayoutParams(dp(54), dp(54)));
        TextView heading = label(title, 20, Color.WHITE, true);
        bar.addView(heading, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        content.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)));
    }

    private LinearLayout page(String title, String subtitle) {
        return page(title, subtitle, false);
    }

    private LinearLayout page(String title, String subtitle, boolean showBack) {
        content.removeAllViews();
        toolbar(title, showBack);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(22), dp(18), dp(40));
        body.addView(label(subtitle, 14, MUTED, false), lpMatchWrap(dp(18)));
        scroll.addView(body);
        content.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return body;
    }

    private void showTardy() {
        activeAttendanceHistoryType = null;
        LinearLayout body = page("Tardy & Call-Outs", "Record a tardy or call-out for today—or choose an earlier date.");
        body.addView(sectionTitle("DATE"));
        Button date = dateButton(selectedTardyDate);
        date.setOnClickListener(v -> pickDate(selectedTardyDate, picked -> { selectedTardyDate = picked; showTardy(); }));
        LinearLayout dateRow = horizontal();
        dateRow.addView(date, new LinearLayout.LayoutParams(0, dp(58), 1));
        dateRow.addView(gap(dp(10)));
        Button today = outlineButton("Today");
        today.setContentDescription("Reset date to today");
        today.setEnabled(!selectedTardyDate.equals(LocalDate.now()));
        today.setAlpha(today.isEnabled() ? 1f : .45f);
        today.setOnClickListener(v -> { selectedTardyDate = LocalDate.now(); showTardy(); });
        dateRow.addView(today, new LinearLayout.LayoutParams(dp(96), dp(58)));
        body.addView(dateRow, lpMatchWrap(dp(18)));

        AttendanceDb.AttendanceEntry existing = db.attendanceFor(selectedTardyDate);
        if (existing != null) {
            String extra = existing.type.equals(AttendanceDb.TARDY) && existing.lateMinutes > 0 ? " • " + PdfExporter.duration(existing.lateMinutes) + " late" : "";
            TextView saved = label("Saved: " + existing.type + extra + ". Saving again will update it.", 13, TEAL, true);
            body.addView(saved, lpMatchWrap(dp(14)));
        }

        body.addView(sectionTitle("SUMMARY"));
        body.addView(filterBar(tardyFilter, true, f -> { tardyFilter = f; showTardy(); }), lpMatchWrap(dp(14)));
        LocalDate[] range = range(tardyFilter, AttendanceDb.TABLE_ATTENDANCE, true);
        List<AttendanceDb.AttendanceEntry> entries = db.attendanceBetween(range[0], range[1]);
        int tardies = 0, calls = 0, lateTotal = 0;
        for (AttendanceDb.AttendanceEntry e : entries) {
            if (e.type.equals(AttendanceDb.TARDY)) { tardies++; lateTotal += e.lateMinutes; } else calls++;
        }
        LinearLayout stats = horizontal();
        stats.addView(attendanceStatCard(String.valueOf(calls), "Call-Outs", AttendanceDb.CALLED_OUT), new LinearLayout.LayoutParams(0, dp(106), 1));
        stats.addView(gap(dp(10)));
        stats.addView(attendanceStatCard(String.valueOf(tardies), "Tardies", AttendanceDb.TARDY), new LinearLayout.LayoutParams(0, dp(106), 1));
        body.addView(stats, lpMatchWrap(dp(10)));
        if (prefs.getBoolean("track_late_minutes", false) && lateTotal > 0) body.addView(infoCard(PdfExporter.duration(lateTotal) + " total late in this filter"), lpMatchWrap(dp(14)));

        body.addView(sectionTitle("MARK THIS DATE"));
        boolean trackLate = prefs.getBoolean("track_late_minutes", false);
        EditText lateHours = numberField("Hours", 2);
        EditText lateMinutes = numberField("Minutes", 2);
        if (trackLate) {
            body.addView(label("How late? (optional)", 13, MUTED, true), lpMatchWrap(dp(8)));
            LinearLayout duration = horizontal();
            duration.addView(lateHours, new LinearLayout.LayoutParams(0, dp(58), 1));
            duration.addView(gap(dp(10)));
            duration.addView(lateMinutes, new LinearLayout.LayoutParams(0, dp(58), 1));
            if (existing != null && existing.type.equals(AttendanceDb.TARDY)) {
                lateHours.setText(String.valueOf(existing.lateMinutes / 60));
                lateMinutes.setText(String.valueOf(existing.lateMinutes % 60));
            }
            body.addView(duration, lpMatchWrap(dp(10)));
        }

        LinearLayout actions = horizontal();
        Button call = button("Called Out", NAVY, Color.WHITE);
        call.setOnClickListener(v -> {
            confirm("Mark called out?", "Save a call-out for " + SHORT_DATE.format(selectedTardyDate) + "?", () -> {
                db.saveAttendance(selectedTardyDate, AttendanceDb.CALLED_OUT, 0);
                syncDriveAfterChange();
                toast("Call-out saved"); showTardy();
            });
        });
        Button tardy = button("Tardy", CORAL, Color.WHITE);
        tardy.setOnClickListener(v -> {
            int mins = trackLate ? readDuration(lateHours, lateMinutes) : 0;
            if (mins < 0) return;
            db.saveAttendance(selectedTardyDate, AttendanceDb.TARDY, mins);
            syncDriveAfterChange();
            toast("Tardy saved for " + SHORT_DATE.format(selectedTardyDate));
            showTardy();
        });
        actions.addView(call, new LinearLayout.LayoutParams(0, dp(56), 1));
        actions.addView(gap(dp(10)));
        actions.addView(tardy, new LinearLayout.LayoutParams(0, dp(56), 1));
        body.addView(actions, lpMatchWrap(dp(12)));
        Button export = outlineButton("Export this view as PDF");
        export.setOnClickListener(v -> exportAttendance(range, entries));
        body.addView(export, lpMatch(dp(56), dp(4)));
    }

    private void showHours() {
        LinearLayout body = page("Hours", "Add your hours worked and keep a running total.");
        body.addView(sectionTitle("DATE"));
        Button date = dateButton(selectedHoursDate);
        date.setOnClickListener(v -> pickDate(selectedHoursDate, picked -> { selectedHoursDate = picked; showHours(); }));
        body.addView(date, lpMatch(dp(58), dp(18)));

        AttendanceDb.HoursEntry existing = db.hoursFor(selectedHoursDate);
        body.addView(sectionTitle("HOURS WORKED"));
        boolean decimalHours = prefs.getBoolean("decimal_hours", true);
        EditText decimal = decimalField("Decimal hours (example: 8.5)");
        EditText hours = numberField("Hours", 3);
        EditText minutes = numberField("Minutes", 2);
        if (decimalHours) {
            if (existing != null) decimal.setText(decimalHours(existing.minutes));
            body.addView(decimal, lpMatch(dp(58), dp(10)));
            body.addView(label("Example: 8.5 = 8 hours 30 minutes", 12, MUTED, false), lpMatchWrap(dp(10)));
        } else {
            LinearLayout duration = horizontal();
            if (existing != null) {
                hours.setText(String.valueOf(existing.minutes / 60));
                minutes.setText(String.valueOf(existing.minutes % 60));
            }
            duration.addView(hours, new LinearLayout.LayoutParams(0, dp(58), 1));
            duration.addView(gap(dp(10)));
            duration.addView(minutes, new LinearLayout.LayoutParams(0, dp(58), 1));
            body.addView(duration, lpMatchWrap(dp(10)));
        }
        Button save = button(existing == null ? "Save hours" : "Update hours", TEAL, Color.WHITE);
        save.setOnClickListener(v -> {
            int total = decimalHours ? readDecimalHours(decimal) : readDuration(hours, minutes);
            if (total <= 0) { if (total == 0) toast("Enter the time you worked"); return; }
            if (total > 24 * 60) { toast("Hours for one date cannot exceed 24"); return; }
            db.saveHours(selectedHoursDate, total);
            syncDriveAfterChange();
            toast("Hours saved for " + SHORT_DATE.format(selectedHoursDate)); showHours();
        });
        body.addView(save, lpMatch(dp(56), dp(24)));

        body.addView(sectionTitle("TOTAL"));
        body.addView(hoursFilterBar(), lpMatchWrap(dp(14)));
        LocalDate[] range = hoursRange(hoursFilter);
        if (range == null) return;
        List<AttendanceDb.HoursEntry> entries = db.hoursBetween(range[0], range[1]);
        int total = 0;
        for (AttendanceDb.HoursEntry e : entries) total += e.minutes;
        body.addView(statCard(formatHours(total), hoursFilter.label, TEAL), lpMatch(dp(112), dp(18)));
        addHoursHistory(body, entries);
        Button export = outlineButton("Export this view as PDF");
        export.setOnClickListener(v -> exportHours(range, entries));
        body.addView(export, lpMatch(dp(56), dp(4)));
    }

    private void showSettings() {
        LinearLayout body = page("Settings", "Personalize Attendance and protect your records.");
        if (settingsNotice != null) {
            body.addView(infoCard(settingsNotice), lpMatchWrap(dp(14)));
            settingsNotice = null;
        }

        LinearLayout categories = horizontal();
        Button general = choiceButton("General", settingsCategory == SettingsCategory.GENERAL);
        Button time = choiceButton("Time", settingsCategory == SettingsCategory.TIME);
        Button data = choiceButton("Data", settingsCategory == SettingsCategory.DATA);
        general.setOnClickListener(v -> { settingsCategory = SettingsCategory.GENERAL; showSettings(); });
        time.setOnClickListener(v -> { settingsCategory = SettingsCategory.TIME; showSettings(); });
        data.setOnClickListener(v -> { settingsCategory = SettingsCategory.DATA; showSettings(); });
        categories.addView(general, new LinearLayout.LayoutParams(0, dp(46), 1));
        categories.addView(gap(dp(8)));
        categories.addView(time, new LinearLayout.LayoutParams(0, dp(46), 1));
        categories.addView(gap(dp(8)));
        categories.addView(data, new LinearLayout.LayoutParams(0, dp(46), 1));
        body.addView(categories, lpMatchWrap(dp(18)));

        if (settingsCategory == SettingsCategory.GENERAL) addGeneralSettings(body);
        else if (settingsCategory == SettingsCategory.TIME) addTimeSettings(body);
        else addDataSettings(body);
    }

    private void addGeneralSettings(LinearLayout body) {
        body.addView(sectionTitle("APPEARANCE"));
        body.addView(toggleCard("Dark mode", "Use a dark color scheme throughout the app.", darkMode, (v, checked) -> {
            prefs.edit().putBoolean("dark_mode", checked).apply(); recreate();
        }), lpMatchWrap(dp(18)));

        body.addView(sectionTitle("DEFAULT OPENING SCREEN"));
        LinearLayout startCard = card();
        startCard.addView(label("Choose where Attendance opens", 16, INK, true), lpMatchWrap(dp(10)));
        LinearLayout startButtons = horizontal();
        boolean startsHours = "HOURS".equals(prefs.getString("default_mode", "TARDY"));
        Button startTardy = choiceButton("Tardy", !startsHours);
        Button startHours = choiceButton("Hours", startsHours);
        startTardy.setOnClickListener(v -> { prefs.edit().putString("default_mode", "TARDY").apply(); showSettings(); });
        startHours.setOnClickListener(v -> { prefs.edit().putString("default_mode", "HOURS").apply(); showSettings(); });
        startButtons.addView(startTardy, new LinearLayout.LayoutParams(0, dp(48), 1));
        startButtons.addView(gap(dp(10)));
        startButtons.addView(startHours, new LinearLayout.LayoutParams(0, dp(48), 1));
        startCard.addView(startButtons);
        body.addView(startCard, lpMatchWrap(dp(18)));
    }

    private void addTimeSettings(LinearLayout body) {
        body.addView(sectionTitle("TARDY DETAILS"));
        body.addView(toggleCard("Track exact late time", "Show hours and minutes when marking a tardy.", prefs.getBoolean("track_late_minutes", false), (v, checked) -> prefs.edit().putBoolean("track_late_minutes", checked).apply()), lpMatchWrap(dp(18)));

        body.addView(sectionTitle("HOURS FORMAT"));
        body.addView(toggleCard("Decimal hour entry", "On: decimal (8.5). Off: hours/minutes (8 hours 30 minutes).", prefs.getBoolean("decimal_hours", true), (v, checked) -> prefs.edit().putBoolean("decimal_hours", checked).apply()), lpMatchWrap(dp(18)));

        body.addView(sectionTitle("PAY PERIODS"));
        LinearLayout periodCard = card();
        periodCard.addView(label("Set your current pay period", 16, INK, true));
        periodCard.addView(label("Choose its first and last date. Attendance automatically calculates the previous pay period using the same number of days.", 13, MUTED, false), lpMatchWrap(dp(12)));
        LocalDate start = savedPayPeriodDate("pay_period_start");
        LocalDate end = savedPayPeriodDate("pay_period_end");
        LinearLayout dates = horizontal();
        Button startButton = outlineButton(start == null ? "Start date" : shortPayDate(start));
        Button endButton = outlineButton(end == null ? "End date" : shortPayDate(end));
        startButton.setOnClickListener(v -> pickDateAllowFuture(start == null ? LocalDate.now() : start, picked -> {
            prefs.edit().putString("pay_period_start", picked.toString()).apply();
            showSettings();
        }));
        endButton.setOnClickListener(v -> pickDateAllowFuture(end == null ? LocalDate.now() : end, picked -> {
            prefs.edit().putString("pay_period_end", picked.toString()).apply();
            showSettings();
        }));
        dates.addView(startButton, new LinearLayout.LayoutParams(0, dp(52), 1));
        dates.addView(gap(dp(10)));
        dates.addView(endButton, new LinearLayout.LayoutParams(0, dp(52), 1));
        periodCard.addView(dates);
        if (start != null && end != null) {
            if (end.isBefore(start)) {
                periodCard.addView(label("The end date must be on or after the start date.", 12, CORAL, true), lpMatchWrap(dp(2)));
            } else {
                LocalDate[] previous = previousPayPeriod(start, end);
                periodCard.addView(label("Current: " + payRangeLabel(start, end), 12, MUTED, false), lpMatchWrap(dp(2)));
                periodCard.addView(label("Last: " + payRangeLabel(previous[0], previous[1]), 12, MUTED, false));
            }
        }
        body.addView(periodCard, lpMatchWrap(dp(18)));
    }

    private void addDataSettings(LinearLayout body) {
        body.addView(sectionTitle("BACKUP & TRANSFER"));
        LinearLayout backupCard = card();
        backupCard.addView(label("Move all data between devices", 16, INK, true));
        backupCard.addView(label("Export one backup file containing tardies, call-outs, hours, and deletions. Importing merges the newest records.", 13, MUTED, false), lpMatchWrap(dp(12)));
        LinearLayout backupButtons = horizontal();
        Button export = outlineButton("Export data");
        export.setOnClickListener(v -> startBackupExport());
        Button importData = outlineButton("Import data");
        importData.setOnClickListener(v -> confirm("Import attendance data?", "The newest records from the selected backup will be merged with this device.", this::startBackupImport));
        backupButtons.addView(export, new LinearLayout.LayoutParams(0, dp(50), 1));
        backupButtons.addView(gap(dp(10)));
        backupButtons.addView(importData, new LinearLayout.LayoutParams(0, dp(50), 1));
        backupCard.addView(backupButtons);
        body.addView(backupCard, lpMatchWrap(dp(18)));

        body.addView(sectionTitle("GOOGLE DRIVE"));
        boolean driveEnabled = prefs.getBoolean("drive_sync", false) && prefs.contains("drive_uri");
        body.addView(toggleCard("Google Drive sync", driveEnabled ? "Connected. Changes are written to your selected Drive file." : "Turn this on to create an Attendance backup file in Google Drive.", driveEnabled, (v, checked) -> {
            if (checked) startDriveCreate(); else disconnectDrive();
        }), lpMatchWrap(dp(10)));
        LinearLayout driveActions = horizontal();
        if (driveEnabled) {
            Button sync = button("Sync now", TEAL, Color.WHITE);
            sync.setOnClickListener(v -> syncDrive(true));
            Button disconnect = outlineButton("Disconnect");
            disconnect.setOnClickListener(v -> disconnectDrive());
            driveActions.addView(sync, new LinearLayout.LayoutParams(0, dp(52), 1));
            driveActions.addView(gap(dp(10)));
            driveActions.addView(disconnect, new LinearLayout.LayoutParams(0, dp(52), 1));
        } else {
            Button create = button("Create Drive file", TEAL, Color.WHITE);
            create.setOnClickListener(v -> startDriveCreate());
            Button link = outlineButton("Link existing");
            link.setOnClickListener(v -> startDriveOpen());
            driveActions.addView(create, new LinearLayout.LayoutParams(0, dp(52), 1));
            driveActions.addView(gap(dp(10)));
            driveActions.addView(link, new LinearLayout.LayoutParams(0, dp(52), 1));
        }
        body.addView(driveActions, lpMatchWrap(dp(18)));

        body.addView(sectionTitle("ABOUT YOUR DATA"));
        body.addView(infoCard("Your database stays private inside the app. Data leaves the device only when you export it or enable a Drive backup file."));
        body.addView(label("Attendance 1.4.0", 12, MUTED, false), lpMatchWrap(dp(16)));
    }

    private void showAttendanceHistory(String type) {
        activeAttendanceHistoryType = type;
        mode = Mode.TARDY;
        LinearLayout body = page("History", "Review, edit, or delete your attendance records.", true);
        body.addView(sectionTitle("VIEW"));
        LinearLayout tabs = horizontal();
        Button tardies = choiceButton("Tardies", AttendanceDb.TARDY.equals(type));
        Button callOuts = choiceButton("Call-Outs", AttendanceDb.CALLED_OUT.equals(type));
        tardies.setOnClickListener(v -> showAttendanceHistory(AttendanceDb.TARDY));
        callOuts.setOnClickListener(v -> showAttendanceHistory(AttendanceDb.CALLED_OUT));
        tabs.addView(tardies, new LinearLayout.LayoutParams(0, dp(48), 1));
        tabs.addView(gap(dp(10)));
        tabs.addView(callOuts, new LinearLayout.LayoutParams(0, dp(48), 1));
        body.addView(tabs, lpMatchWrap(dp(18)));

        body.addView(sectionTitle("FILTER"));
        body.addView(filterBar(tardyFilter, true, f -> { tardyFilter = f; showAttendanceHistory(type); }), lpMatchWrap(dp(14)));
        LocalDate[] range = range(tardyFilter, AttendanceDb.TABLE_ATTENDANCE, true);
        List<AttendanceDb.AttendanceEntry> allEntries = db.attendanceBetween(range[0], range[1]);
        java.util.ArrayList<AttendanceDb.AttendanceEntry> entries = new java.util.ArrayList<>();
        for (AttendanceDb.AttendanceEntry entry : allEntries) if (entry.type.equals(type)) entries.add(entry);

        body.addView(sectionTitle(type.equals(AttendanceDb.TARDY) ? "TARDIES" : "CALL-OUTS"));
        if (entries.isEmpty()) {
            body.addView(emptyCard(type.equals(AttendanceDb.TARDY) ? "No tardies in this range." : "No call-outs in this range."), lpMatchWrap(dp(18)));
        } else {
            for (AttendanceDb.AttendanceEntry entry : entries) {
                String detail = entry.type.equals(AttendanceDb.TARDY)
                        ? (entry.lateMinutes > 0 ? "Tardy • " + PdfExporter.duration(entry.lateMinutes) + " late" : "Tardy")
                        : "Called Out";
                body.addView(historyRow(SHORT_DATE.format(entry.date), detail,
                        () -> showAttendanceEditor(entry),
                        () -> confirmDelete(() -> {
                            db.deleteAttendance(entry.id);
                            syncDriveAfterChange();
                            showAttendanceHistory(type);
                        })), lpMatchWrap(dp(8)));
            }
        }
        Button export = outlineButton("Export this history as PDF");
        export.setOnClickListener(v -> {
            try { share(PdfExporter.attendance(this, (type.equals(AttendanceDb.TARDY) ? "Tardies • " : "Call-Outs • ") + filterLabel(tardyFilter, true), range[0], range[1], entries)); }
            catch (IOException e) { toast("Could not create the PDF"); }
        });
        body.addView(export, lpMatch(dp(56), dp(4)));
    }

    private void addHoursHistory(LinearLayout body, List<AttendanceDb.HoursEntry> entries) {
        body.addView(sectionTitle("HISTORY"));
        if (entries.isEmpty()) { body.addView(emptyCard("No hours saved in this range."), lpMatchWrap(dp(18))); return; }
        for (AttendanceDb.HoursEntry e : entries) {
            body.addView(historyRow(SHORT_DATE.format(e.date), formatHours(e.minutes), () -> { selectedHoursDate = e.date; showHours(); }, () -> confirmDelete(() -> { db.deleteHours(e.id); syncDriveAfterChange(); showHours(); })), lpMatchWrap(dp(8)));
        }
    }

    private LinearLayout toggleCard(String title, String subtitle, boolean checked, CompoundButton.OnCheckedChangeListener listener) {
        LinearLayout row = card();
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(label(title, 16, INK, true));
        copy.addView(label(subtitle, 13, MUTED, false));
        row.addView(copy, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Switch toggle = new Switch(this);
        toggle.setChecked(checked);
        toggle.setContentDescription(title);
        toggle.setOnCheckedChangeListener(listener);
        row.addView(toggle, new LinearLayout.LayoutParams(dp(58), ViewGroup.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private Button choiceButton(String text, boolean selected) {
        Button button = button(text, selected ? TEAL : CARD_COLOR, selected ? Color.WHITE : INK);
        button.setBackground(selected ? roundRect(TEAL, 14) : bordered(CARD_COLOR, BORDER, 14));
        return button;
    }

    private void startBackupExport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "Attendance-backup-" + LocalDate.now() + ".json");
        startActivityForResult(intent, EXPORT_BACKUP);
    }

    private void startBackupImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, IMPORT_BACKUP);
    }

    private void startDriveCreate() {
        toast("Choose Google Drive from the Locations menu");
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "Attendance-Drive-Backup.json");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, DRIVE_CREATE);
    }

    private void startDriveOpen() {
        toast("Choose your Attendance backup file in Google Drive");
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, DRIVE_OPEN);
    }

    private void disconnectDrive() {
        prefs.edit().putBoolean("drive_sync", false).remove("drive_uri").apply();
        toast("Google Drive sync disconnected");
        showSettings();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            if (requestCode == DRIVE_CREATE || requestCode == DRIVE_OPEN) showSettings();
            return;
        }
        Uri uri = data.getData();
        if (requestCode == EXPORT_BACKUP) {
            writeBackup(uri, "Backup exported");
        } else if (requestCode == IMPORT_BACKUP) {
            importBackup(uri);
        } else if (requestCode == DRIVE_CREATE || requestCode == DRIVE_OPEN) {
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (SecurityException ignored) { }
            showSettings();
            connectDriveFile(uri, requestCode == DRIVE_CREATE);
        }
    }

    private void connectDriveFile(Uri uri, boolean createNew) {
        new Thread(() -> {
            try {
                if (!createNew) {
                    String cloud = BackupManager.read(getContentResolver(), uri);
                    if (!cloud.trim().isEmpty()) BackupManager.mergeJson(db, cloud);
                }
                BackupManager.write(getContentResolver(), uri, BackupManager.createJson(db));
                prefs.edit().putString("drive_uri", uri.toString()).putBoolean("drive_sync", true).apply();
                runOnUiThread(() -> {
                    toast(createNew ? "Drive sync file created" : "Drive backup linked and synced");
                    refreshCurrentMode();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    toast(createNew ? "Could not create the Drive sync file" : "Could not link that Drive backup");
                    showSettings();
                });
            }
        }).start();
    }

    private void writeBackup(Uri uri, String successMessage) {
        new Thread(() -> {
            try {
                BackupManager.write(getContentResolver(), uri, BackupManager.createJson(db));
                runOnUiThread(() -> toast(successMessage));
            } catch (Exception e) {
                runOnUiThread(() -> toast("Could not write the backup file"));
            }
        }).start();
    }

    private void importBackup(Uri uri) {
        new Thread(() -> {
            try {
                int merged = BackupManager.mergeJson(db, BackupManager.read(getContentResolver(), uri));
                runOnUiThread(() -> {
                    toast("Backup imported • " + merged + " records checked");
                    refreshCurrentMode();
                    syncDriveAfterChange();
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("That file is not a valid Attendance backup"));
            }
        }).start();
    }

    private void syncDriveAfterChange() {
        if (prefs.getBoolean("drive_sync", false) && prefs.contains("drive_uri")) syncDrive(false);
    }

    private void syncDrive(boolean showFeedback) {
        String savedUri = prefs.getString("drive_uri", null);
        if (savedUri == null) {
            if (showFeedback) toast("Connect a Google Drive backup first");
            return;
        }
        Uri uri = Uri.parse(savedUri);
        new Thread(() -> {
            try {
                String cloud = BackupManager.read(getContentResolver(), uri);
                if (!cloud.trim().isEmpty()) BackupManager.mergeJson(db, cloud);
                BackupManager.write(getContentResolver(), uri, BackupManager.createJson(db));
                runOnUiThread(() -> {
                    if (showFeedback) toast("Google Drive sync complete");
                    refreshCurrentMode();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (showFeedback) toast("Could not sync the Google Drive backup");
                });
            }
        }).start();
    }

    private void refreshCurrentMode() {
        if (mode == Mode.TARDY && activeAttendanceHistoryType != null) showAttendanceHistory(activeAttendanceHistoryType);
        else if (mode == Mode.TARDY) showTardy();
        else if (mode == Mode.HOURS) showHours();
        else showSettings();
    }

    private void showAttendanceEditor(AttendanceDb.AttendanceEntry entry) {
        boolean trackLate = prefs.getBoolean("track_late_minutes", false);
        int[] selectedType = {entry.type.equals(AttendanceDb.TARDY) ? 1 : 0};
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(20), dp(4), dp(20), 0);
        form.addView(label(SHORT_DATE.format(entry.date), 14, MUTED, true), lpMatchWrap(dp(10)));

        EditText lateHours = numberField("Hours late", 2);
        EditText lateMinutes = numberField("Minutes late", 2);
        if (trackLate) {
            lateHours.setText(String.valueOf(entry.lateMinutes / 60));
            lateMinutes.setText(String.valueOf(entry.lateMinutes % 60));
            form.addView(label("Late time (used only for Tardy)", 13, MUTED, false), lpMatchWrap(dp(7)));
            LinearLayout duration = horizontal();
            duration.addView(lateHours, new LinearLayout.LayoutParams(0, dp(54), 1));
            duration.addView(gap(dp(10)));
            duration.addView(lateMinutes, new LinearLayout.LayoutParams(0, dp(54), 1));
            form.addView(duration);
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Edit attendance entry")
                .setSingleChoiceItems(new String[]{"Called Out", "Tardy"}, selectedType[0], (d, which) -> selectedType[0] = which)
                .setView(form)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save changes", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(button -> {
            int minutes = trackLate && selectedType[0] == 1 ? readDuration(lateHours, lateMinutes) : (selectedType[0] == 1 ? entry.lateMinutes : 0);
            if (minutes < 0) return;
            db.saveAttendance(entry.date, selectedType[0] == 1 ? AttendanceDb.TARDY : AttendanceDb.CALLED_OUT, minutes);
            syncDriveAfterChange();
            dialog.dismiss();
            toast("Attendance entry updated");
            if (activeAttendanceHistoryType != null) showAttendanceHistory(activeAttendanceHistoryType); else showTardy();
        }));
        dialog.show();
    }

    private View historyRow(String title, String detail, Runnable edit, Runnable delete) {
        LinearLayout row = card();
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(label(title, 15, INK, true));
        copy.addView(label(detail, 13, MUTED, false));
        row.addView(copy, new LinearLayout.LayoutParams(0, dp(58), 1));
        Button editButton = button("Edit", Color.TRANSPARENT, darkMode ? TEAL : NAVY);
        editButton.setBackground(bordered(Color.TRANSPARENT, darkMode ? TEAL : NAVY, 12));
        editButton.setContentDescription("Edit entry");
        editButton.setOnClickListener(v -> edit.run());
        row.addView(editButton, new LinearLayout.LayoutParams(dp(64), dp(44)));
        row.addView(gap(dp(7)));
        Button remove = button("Delete", Color.TRANSPARENT, CORAL);
        remove.setTextSize(12);
        remove.setBackground(bordered(Color.TRANSPARENT, CORAL, 12));
        remove.setContentDescription("Delete entry");
        remove.setOnClickListener(v -> delete.run());
        row.addView(remove, new LinearLayout.LayoutParams(dp(72), dp(44)));
        return row;
    }

    private HorizontalScrollView hoursFilterBar() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row = horizontal();
        for (HoursFilter filter : HoursFilter.values()) {
            Button button = button(filter.label, filter == hoursFilter ? NAVY : CARD_COLOR, filter == hoursFilter ? Color.WHITE : INK);
            button.setBackground(filter == hoursFilter ? roundRect(NAVY, 20) : bordered(CARD_COLOR, BORDER, 20));
            button.setOnClickListener(v -> {
                if ((filter == HoursFilter.CURRENT_PAY_PERIOD || filter == HoursFilter.LAST_PAY_PERIOD) && !hasValidPayPeriod()) {
                    mode = Mode.SETTINGS;
                    settingsCategory = SettingsCategory.TIME;
                    settingsNotice = "Set your current pay period start and end dates before using pay-period totals.";
                    showSettings();
                    return;
                }
                hoursFilter = filter;
                showHours();
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42));
            params.setMarginEnd(dp(8));
            row.addView(button, params);
        }
        scroll.addView(row);
        return scroll;
    }

    private LocalDate[] hoursRange(HoursFilter filter) {
        LocalDate today = LocalDate.now();
        LocalDate thisSunday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));
        if (filter == HoursFilter.CURRENT_WEEK) return new LocalDate[]{thisSunday, thisSunday.plusDays(6)};
        if (filter == HoursFilter.LAST_WEEK) return new LocalDate[]{thisSunday.minusDays(7), thisSunday.minusDays(1)};
        LocalDate start = savedPayPeriodDate("pay_period_start");
        LocalDate end = savedPayPeriodDate("pay_period_end");
        if (start == null || end == null || end.isBefore(start)) {
            mode = Mode.SETTINGS;
            settingsCategory = SettingsCategory.TIME;
            settingsNotice = "Set a valid current pay period start and end date to use this filter.";
            showSettings();
            return null;
        }
        return filter == HoursFilter.CURRENT_PAY_PERIOD ? new LocalDate[]{start, end} : previousPayPeriod(start, end);
    }

    private LocalDate[] previousPayPeriod(LocalDate currentStart, LocalDate currentEnd) {
        long days = ChronoUnit.DAYS.between(currentStart, currentEnd) + 1;
        LocalDate lastEnd = currentStart.minusDays(1);
        return new LocalDate[]{lastEnd.minusDays(days - 1), lastEnd};
    }

    private boolean hasValidPayPeriod() {
        LocalDate start = savedPayPeriodDate("pay_period_start");
        LocalDate end = savedPayPeriodDate("pay_period_end");
        return start != null && end != null && !end.isBefore(start);
    }

    private LocalDate savedPayPeriodDate(String key) {
        String value = prefs.getString(key, null);
        if (value == null) return null;
        try { return LocalDate.parse(value); }
        catch (RuntimeException ignored) { return null; }
    }

    private String shortPayDate(LocalDate date) {
        return date.format(DateTimeFormatter.ofPattern("MMM d, uuuu", Locale.US));
    }

    private String payRangeLabel(LocalDate start, LocalDate end) {
        return shortPayDate(start) + " – " + shortPayDate(end);
    }

    private HorizontalScrollView filterBar(Filter selected, boolean tardyMode, FilterAction action) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row = horizontal();
        for (Filter f : Filter.values()) {
            String text = f == Filter.MONTH ? (f == selected ? filterLabel(f, tardyMode) : "Month") + " ▾" : f == Filter.YEAR ? (f == selected ? filterLabel(f, tardyMode) : "Year") + " ▾" : f.label;
            Button b = button(text, f == selected ? NAVY : CARD_COLOR, f == selected ? Color.WHITE : INK);
            b.setBackground(f == selected ? roundRect(NAVY, 20) : bordered(CARD_COLOR, BORDER, 20));
            b.setOnClickListener(v -> {
                if (f == Filter.MONTH) showMonthPicker(tardyMode, action);
                else if (f == Filter.YEAR) showYearPicker(tardyMode, action);
                else action.select(f);
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42));
            p.setMarginEnd(dp(8)); row.addView(b, p);
        }
        scroll.addView(row);
        return scroll;
    }

    private LocalDate[] range(Filter filter, String table, boolean tardyMode) {
        LocalDate today = LocalDate.now();
        switch (filter) {
            case DAYS_30: return new LocalDate[]{today.minusDays(29), today};
            case MONTH:
                YearMonth month = selectedTardyMonth;
                LocalDate monthEnd = month.equals(YearMonth.now()) ? today : month.atEndOfMonth();
                return new LocalDate[]{month.atDay(1), monthEnd};
            case YEAR:
                int year = selectedTardyYear;
                return new LocalDate[]{LocalDate.of(year, 1, 1), year == today.getYear() ? today : LocalDate.of(year, 12, 31)};
            default: return new LocalDate[]{db.earliestDate(table), today};
        }
    }

    private String filterLabel(Filter filter, boolean tardyMode) {
        if (filter == Filter.MONTH) return MONTH_LABEL.format(selectedTardyMonth);
        if (filter == Filter.YEAR) return String.valueOf(selectedTardyYear);
        return filter.label;
    }

    private void showMonthPicker(boolean tardyMode, FilterAction action) {
        YearMonth selected = selectedTardyMonth;
        int selectedYear = selectedTardyYear;
        NumberPicker month = new NumberPicker(this);
        int maxMonth = selectedYear == LocalDate.now().getYear() ? LocalDate.now().getMonthValue() : 12;
        month.setMinValue(1); month.setMaxValue(maxMonth);
        month.setValue(Math.min(selected.getMonthValue(), maxMonth));
        String[] monthNames = new String[]{"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        String[] displayedMonths = new String[maxMonth];
        System.arraycopy(monthNames, 0, displayedMonths, 0, maxMonth);
        month.setDisplayedValues(displayedMonths);
        month.setWrapSelectorWheel(false);
        new AlertDialog.Builder(this).setTitle("Choose month in " + selectedYear).setView(month).setNegativeButton("Cancel", null).setPositiveButton("Use month", (d, w) -> {
            YearMonth choice = YearMonth.of(selectedYear, month.getValue());
            selectedTardyMonth = choice;
            action.select(Filter.MONTH);
        }).show();
    }

    private void showYearPicker(boolean tardyMode, FilterAction action) {
        NumberPicker year = new NumberPicker(this);
        year.setMinValue(2000); year.setMaxValue(LocalDate.now().getYear());
        year.setValue(selectedTardyYear);
        year.setWrapSelectorWheel(false);
        new AlertDialog.Builder(this).setTitle("Choose year").setView(year).setNegativeButton("Cancel", null).setPositiveButton("Use year", (d, w) -> {
            int chosenYear = year.getValue();
            selectedTardyYear = chosenYear;
            int month = Math.min(selectedTardyMonth.getMonthValue(), chosenYear == LocalDate.now().getYear() ? LocalDate.now().getMonthValue() : 12);
            selectedTardyMonth = YearMonth.of(chosenYear, month);
            action.select(Filter.YEAR);
        }).show();
    }

    private void exportAttendance(LocalDate[] range, List<AttendanceDb.AttendanceEntry> entries) {
        try { share(PdfExporter.attendance(this, filterLabel(tardyFilter, true), range[0], range[1], entries)); }
        catch (IOException e) { toast("Could not create the PDF"); }
    }

    private void exportHours(LocalDate[] range, List<AttendanceDb.HoursEntry> entries) {
        try { share(PdfExporter.hours(this, hoursFilter.label, range[0], range[1], entries, prefs.getBoolean("decimal_hours", true))); }
        catch (IOException e) { toast("Could not create the PDF"); }
    }

    private void share(Uri uri) {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("application/pdf");
        send.putExtra(Intent.EXTRA_STREAM, uri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, "Share attendance PDF"));
    }

    private void pickDate(LocalDate initial, DateAction action) {
        DatePickerDialog dialog = new DatePickerDialog(this, (v, y, m, d) -> action.select(LocalDate.of(y, m + 1, d)), initial.getYear(), initial.getMonthValue() - 1, initial.getDayOfMonth());
        dialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        dialog.show();
    }

    private void pickDateAllowFuture(LocalDate initial, DateAction action) {
        new DatePickerDialog(this, (v, y, m, d) -> action.select(LocalDate.of(y, m + 1, d)), initial.getYear(), initial.getMonthValue() - 1, initial.getDayOfMonth()).show();
    }

    private Button dateButton(LocalDate date) {
        Button b = button(FULL_DATE.format(date) + "   ▾", CARD_COLOR, INK);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setPadding(dp(18), 0, dp(14), 0);
        b.setBackground(bordered(CARD_COLOR, BORDER, 14));
        return b;
    }

    private LinearLayout statCard(String value, String caption, int accent) {
        LinearLayout card = card();
        card.setGravity(Gravity.CENTER_VERTICAL);
        TextView number = label(value, value.length() > 8 ? 25 : 34, accent, true);
        card.addView(number);
        card.addView(label(caption, 13, MUTED, false));
        return card;
    }

    private LinearLayout attendanceStatCard(String value, String caption, String type) {
        LinearLayout card = statCard(value, caption, darkMode ? INK : NAVY);
        card.setClickable(true);
        card.setFocusable(true);
        card.setContentDescription(caption + ": " + value + ". Tap to view history.");
        card.setOnClickListener(v -> showAttendanceHistory(type));
        return card;
    }

    private LinearLayout infoCard(String text) {
        LinearLayout card = card();
        card.setBackground(bordered(darkMode ? Color.rgb(20, 55, 57) : Color.rgb(232, 247, 244), darkMode ? Color.rgb(45, 105, 102) : Color.rgb(182, 228, 220), 14));
        card.addView(label(text, 13, darkMode ? Color.rgb(166, 231, 222) : Color.rgb(20, 105, 95), false));
        return card;
    }

    private LinearLayout emptyCard(String text) {
        LinearLayout card = card();
        card.addView(label(text, 13, MUTED, false));
        return card;
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(roundRect(CARD_COLOR, 14));
        card.setElevation(dp(1));
        return card;
    }

    private TextView sectionTitle(String text) {
        TextView v = label(text, 12, MUTED, true);
        v.setLetterSpacing(.09f);
        v.setPadding(0, dp(12), 0, dp(9));
        return v;
    }

    private TextView label(String text, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String text, int background, int color) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(14); b.setTextColor(color); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setBackground(roundRect(background, 14));
        b.setStateListAnimator(null);
        return b;
    }

    private Button outlineButton(String text) {
        int accent = darkMode ? TEAL : NAVY;
        Button b = button(text, Color.TRANSPARENT, accent);
        b.setBackground(bordered(Color.TRANSPARENT, accent, 14));
        return b;
    }

    private EditText numberField(String hint, int maxDigits) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextSize(16); e.setTextColor(INK); e.setHintTextColor(MUTED);
        e.setSingleLine(true); e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setPadding(dp(16), 0, dp(12), 0);
        e.setBackground(bordered(CARD_COLOR, BORDER, 14));
        e.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(maxDigits)});
        return e;
    }

    private EditText decimalField(String hint) {
        EditText field = numberField(hint, 5);
        field.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return field;
    }

    private int readDecimalHours(EditText field) {
        String value = field.getText().toString().trim();
        if (value.isEmpty()) return 0;
        try {
            BigDecimal hours = new BigDecimal(value);
            if (hours.signum() < 0) throw new NumberFormatException();
            return hours.multiply(BigDecimal.valueOf(60)).setScale(0, RoundingMode.HALF_UP).intValueExact();
        } catch (ArithmeticException | NumberFormatException ex) {
            toast("Enter valid decimal hours, such as 8.5");
            return -1;
        }
    }

    private String decimalHours(int minutes) {
        return BigDecimal.valueOf(minutes).divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
    }

    private String formatHours(int minutes) {
        if (prefs.getBoolean("decimal_hours", true)) {
            return BigDecimal.valueOf(minutes).divide(BigDecimal.valueOf(60), 2, RoundingMode.HALF_UP).setScale(2, RoundingMode.HALF_UP).toPlainString() + " hours";
        }
        return PdfExporter.duration(minutes);
    }

    private int readDuration(EditText hours, EditText minutes) {
        try {
            int h = hours.getText().length() == 0 ? 0 : Integer.parseInt(hours.getText().toString());
            int m = minutes.getText().length() == 0 ? 0 : Integer.parseInt(minutes.getText().toString());
            if (m > 59) { toast("Minutes must be between 0 and 59"); return -1; }
            return h * 60 + m;
        } catch (NumberFormatException ex) { toast("Please enter a valid time"); return -1; }
    }

    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private GradientDrawable bordered(int fill, int stroke, int radius) {
        GradientDrawable d = roundRect(fill, radius); d.setStroke(dp(1), stroke); return d;
    }

    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private Space gap(int width) { Space s = new Space(this); s.setLayoutParams(new LinearLayout.LayoutParams(width, 1)); return s; }
    private FrameLayout.LayoutParams matchFrame() { return new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT); }
    private LinearLayout.LayoutParams lpMatch(int height, int bottom) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height); p.bottomMargin = bottom; return p; }
    private LinearLayout.LayoutParams lpMatchWrap(int bottom) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.bottomMargin = bottom; return p; }
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private void openDrawer() {
        drawerOpen = true; scrim.setVisibility(View.VISIBLE); drawer.bringToFront();
        drawer.animate().translationX(0).setDuration(190).start();
    }

    private void closeDrawer() {
        drawerOpen = false;
        drawer.animate().translationX(-drawer.getWidth()).setDuration(170).withEndAction(() -> { scrim.setVisibility(View.GONE); content.bringToFront(); scrim.bringToFront(); drawer.bringToFront(); }).start();
    }

    @Override public boolean dispatchTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { touchDownX = e.getX(); touchDownY = e.getY(); }
        if (e.getActionMasked() == MotionEvent.ACTION_UP) {
            float dx = e.getX() - touchDownX, dy = Math.abs(e.getY() - touchDownY);
            if (!drawerOpen && touchDownX < dp(36) && dx > dp(70) && Math.abs(dx) > dy) { openDrawer(); return true; }
            if (drawerOpen && dx < -dp(70) && Math.abs(dx) > dy) { closeDrawer(); return true; }
        }
        return super.dispatchTouchEvent(e);
    }

    @Override public void onBackPressed() {
        if (drawerOpen) closeDrawer(); else super.onBackPressed();
    }

    private void confirmDelete(Runnable action) { confirm("Delete this entry?", "This cannot be undone.", action); }
    private void confirm(String title, String message, Runnable action) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setNegativeButton("Cancel", null).setPositiveButton("Confirm", (d, w) -> action.run()).show();
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }

    private interface DateAction { void select(LocalDate date); }
    private interface FilterAction { void select(Filter filter); }
}
